<?php
/*
 * @package Joomla
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 *
 * @component jDownloads
 * @version 2.0  
 * @copyright (C) 2007 - 2011 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\Utilities\ArrayHelper;

jimport('joomla.application.component.controller');

/**
 * jDownloads layoutinstall Controller
 *
 */
class jdownloadsControllerLayoutinstall extends jdownloadsController
{
    /**
     * Constructor
     */
    function __construct()
    {
        parent::__construct();
    }
    
	/**
	 * logic to store the data from the layout file in the database
	 *
	 */
	public function install()
    {
        global $jlistConfig;
        
        // Check for request forgeries.
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

        // Access check.
        if (!JFactory::getUser()->authorise('edit.config','com_jdownloads')){            
            JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
            $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false));
            
        } else {       
        
            jimport('joomla.filesystem.file');
            
            $app = JFactory::getApplication();
            $db = JFactory::getDBO();
            
            ini_set('max_execution_time', '300');
            ignore_user_abort(true);
            flush(); 
            
            // get layout file
            $file = ArrayHelper::getValue($_FILES, 'install_file', array('tmp_name'=>'', 'name'=>'', 'error'=>UPLOAD_ERR_NO_FILE, 'size'=>0));
            
            // Parse the administrator-supplied XML in memory. Never copy an
            // attacker-controlled filename into a web-accessible download tree.
            if ((int) $file['error'] !== UPLOAD_ERR_OK ||
                strtolower(JFile::getExt($file['name'])) !== 'xml' ||
                (int) $file['size'] < 1 || (int) $file['size'] > 2097152 ||
                !is_uploaded_file($file['tmp_name'])) {
                $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false),  JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_WRONG_FILE_ERROR'), 'error');
                return;
            }

            $layout_xml = file_get_contents($file['tmp_name']);
            if ($layout_xml === false || preg_match('/<!DOCTYPE|<!ENTITY/i', $layout_xml)) {
                $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false), JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_WRONG_FILE_ERROR'), 'error');
                return;
            }

            $old_libxml = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($layout_xml, 'SimpleXMLElement', LIBXML_NONET);
            libxml_clear_errors();
            libxml_use_internal_errors($old_libxml);

            if ($xml !== false && $xml->template_typ){
                if ($xml->targetjdownloads){
                    // versions check
                    $current_version = JDownloadsHelper::getjDownloadsVersion();
                    $result = version_compare($xml->targetjdownloads, $current_version, '<=');
                    if (!$result){
                        // installed version is to old for this layout
                        $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false),  JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_WRONG_VERSION_ERROR'), 'error');
                    }
                }
                
                switch ($xml->template_typ) {
                    case 'categories':
                        $xml->template_typ = '1';
                        break; 
                    case 'category':
                        $xml->template_typ = '4';                    
                        break;
                    case 'files':
                        $xml->template_typ = '2';                                        
                        break;
                    case 'details':
                        $xml->template_typ = '5';                                        
                        break;
                    case 'summary':
                        $xml->template_typ = '3';                                        
                        break;
                    case 'search':
                        $xml->template_typ = '7';                                        
                        break;
                    default:
                        // wrong layout type
                        $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false), JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_WRONG_FILE_ERROR'), 'error');
                }

                $xml->note                      = trim((string) $xml->note);
                $xml->template_header_text      = trim((string) $xml->template_header_text);
                $xml->template_subheader_text   = trim((string) $xml->template_subheader_text);
                $xml->template_footer_text      = trim((string) $xml->template_footer_text);
                $xml->template_before_text      = trim((string) $xml->template_before_text);
                $xml->template_text             = trim((string) $xml->template_text);
                $xml->template_after_text       = trim((string) $xml->template_after_text);

                if ($xml->author != ''){
                    $note = $xml->note."\r\n{".JText::_('COM_JDOWNLOADS_BACKEND_FILESLIST_AUTHOR').': '.$xml->author;
                    if ($xml->creation_date != ''){
                        $note .= ' - '.$xml->creation_date.'}';
                    } else {
                        $note .= '}';
                    }
                } else {
                    $note = $xml->note;
                }
                
                $template = new stdClass();
                $template->template_name = (string) $xml->template_name;
                $template->template_typ = (int) $xml->template_typ;
                $template->template_header_text = (string) $xml->template_header_text;
                $template->template_subheader_text = (string) $xml->template_subheader_text;
                $template->template_footer_text = (string) $xml->template_footer_text;
                $template->template_before_text = (string) $xml->template_before_text;
                $template->template_text = (string) $xml->template_text;
                $template->template_after_text = (string) $xml->template_after_text;
                $template->template_active = (int) $xml->template_active;
                $template->locked = (int) $xml->locked;
                $template->note = (string) $note;
                $template->cols = (int) $xml->cols;
                $template->checkbox_off = (int) $xml->checkbox_off;
                $template->use_to_view_subcats = (int) $xml->use_to_view_subcats;
                $template->symbol_off = (int) $xml->symbol_off;
                $template->language = (string) $xml->language;
                $result = $db->insertObject('#__jdownloads_templates', $template);
                if (!$result){
                    // MySQL error
                    $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false),  JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_MYSQL_ERROR'), 'error');
                } 
            } else {
                // invalid file
                $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false),  JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_WRONG_FILE_ERROR'), 'error');
            }                        
        }
        $app->redirect(JRoute::_('index.php?option=com_jdownloads&view=layouts', false), JText::_('COM_JDOWNLOADS_LAYOUTS_IMPORT_MSG_SUCCESSFUL') );
    }
}
?>
