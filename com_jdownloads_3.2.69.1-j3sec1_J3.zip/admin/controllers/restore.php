<?php
/*
 * @package Joomla
 * @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 *
 * @component jDownloads
 * @version 2.0  
 * @copyright (C) 2007 - 2011 - Arno Betz - www.jdownloads.com
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.txt
 * 
 * jDownloads is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

use Joomla\Utilities\ArrayHelper;

jimport('joomla.application.component.controller');

/**
 * jDownloads Restore Controller
 *
 */
class jdownloadsControllerrestore extends jdownloadsController
{
	/**
	 * Constructor
	 *
	 */
	    public function __construct($config = array())
    {
        parent::__construct($config);
       
	}

    /**
     * Read a legacy jDownloads backup as data. The original implementation
     * executed the uploaded file with require_once(), making the restore
     * feature an arbitrary PHP execution path.
     */
    private function executeRestoreFile($path)
    {
        $contents = @file_get_contents($path);

        if ($contents === false || trim($contents) === '') {
            throw new RuntimeException(JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'));
        }

        $pattern = '/\$db->setQuery\("((?:\\\\.|[^"\\\\])*)"\)\s*;\s*\$db->execute\(\)\s*;\s*(?:\$i\+\+\s*;\s*)?/s';
        preg_match_all($pattern, $contents, $matches, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);

        if (empty($matches)) {
            throw new RuntimeException(JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'));
        }

        $queries = array();
        $cursor = 0;

        foreach ($matches as $match) {
            $offset = $match[0][1];
            $gap = substr($contents, $cursor, $offset - $cursor);
            $gap = preg_replace('/<\?php|\?>|\$i\s*=\s*\d+\s*;/i', '', $gap);

            if (trim($gap) !== '') {
                throw new RuntimeException(JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'));
            }

            $query = stripcslashes($match[1][0]);

            if (!$this->isAllowedRestoreQuery($query)) {
                throw new RuntimeException(JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'));
            }

            $queries[] = $query;
            $cursor = $offset + strlen($match[0][0]);
        }

        $tail = preg_replace('/<\?php|\?>/i', '', substr($contents, $cursor));
        if (trim($tail) !== '') {
            throw new RuntimeException(JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'));
        }

        $db = JFactory::getDbo();
        $restoredRows = 0;

        foreach ($queries as $query) {
            $db->setQuery($query);
            $db->execute();

            if (stripos(ltrim($query), 'INSERT INTO ') === 0) {
                $restoredRows++;
            }
        }

        return $restoredRows;
    }

    /**
     * Permit only the tables and statement shapes produced by the bundled
     * Joomla 3 jDownloads backup controller.
     */
    private function isAllowedRestoreQuery($query)
    {
        $query = trim((string) $query);
        $queryWithoutTerminator = rtrim($query, "; \t\r\n\0\x0B");

        if (!$this->isSingleSqlStatement($queryWithoutTerminator)) {
            return false;
        }

        $table = '(config|categories|files|licenses|ratings|logs|templates|usergroups_limits)';
        $patterns = array(
            '/^TRUNCATE\s+TABLE\s+`#__jdownloads_'.$table.'`$/i',
            '/^DELETE\s+FROM\s+`#__assets`\s+WHERE\s+`name`\s+LIKE\s+\'com_jdownloads%\'\s+AND\s+`level`\s*>\s*\'1\'$/i',
            '/^INSERT\s+INTO\s+#__jdownloads_'.$table.'\s*\(\s*(?:`[A-Za-z0-9_]+`\s*,?\s*)+\)\s+VALUES\s*\(.+\)$/is'
        );

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $queryWithoutTerminator)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Reject extra statements and SQL comment syntax outside quoted values.
     */
    private function isSingleSqlStatement($query)
    {
        $inString = false;
        $length = strlen($query);

        for ($i = 0; $i < $length; $i++) {
            $char = $query[$i];

            if ($inString && $char === '\\') {
                $i++;
                continue;
            }

            if ($char === "'") {
                if ($inString && $i + 1 < $length && $query[$i + 1] === "'") {
                    $i++;
                    continue;
                }

                $inString = !$inString;
                continue;
            }

            if (!$inString) {
                $isJoomlaPrefix = $char === '#' && substr($query, $i, 3) === '#__';
                if ($char === ';' || ($char === '#' && !$isJoomlaPrefix) || ($char === '/' && $i + 1 < $length && $query[$i + 1] === '*') || ($char === '-' && $i + 1 < $length && $query[$i + 1] === '-')) {
                    return false;
                }
            }
        }

        return !$inString;
    }

	/**
	 * logic to restore the backup file
	 *
	 */
	public function runrestore()
    {
        global $jlistConfig;
        
        // Check for request forgeries.
        JSession::checkToken() or jexit(JText::_('JINVALID_TOKEN'));

        // Access check.
        if (!JFactory::getUser()->authorise('core.admin','com_jdownloads')){            
            JError::raiseWarning(404, JText::_('JERROR_ALERTNOAUTHOR'));
            $this->setRedirect(JRoute::_('index.php?option=com_jdownloads&view=tools', true));
            
        } else {       
        
            jimport('joomla.filesystem.file');
            
            $model_category = JModelLegacy::getInstance( 'Category', 'jdownloadsModel' );
            $model_download = JModelLegacy::getInstance( 'Download', 'jdownloadsModel' );        
        
            $db = JFactory::getDBO();
            $user = JFactory::getUser();
            
            ini_set('max_execution_time', '600');
            ignore_user_abort(true);
            flush(); 
            
            $target_prefix = JDownloadshelper::getCorrectDBPrefix();
            
            $app = JFactory::getApplication();
            
            $original_upload_dir = $jlistConfig['files.uploaddir'];
            
            $output = '';
            $log = '';

            // Get and strictly validate the restore file. It is stored under
            // Joomla's temporary directory and is never included as PHP.
            $file = ArrayHelper::getValue($_FILES, 'restore_file', array('tmp_name' => '', 'name' => '', 'error' => UPLOAD_ERR_NO_FILE, 'size' => 0));
            $safe_name = JFile::makeSafe(basename(str_replace('\\', '/', (string) $file['name'])));

            if ((int) $file['error'] !== UPLOAD_ERR_OK ||
                empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name']) ||
                (int) $file['size'] < 1 || (int) $file['size'] > 52428800 ||
                empty($safe_name) || strtolower(JFile::getExt($safe_name)) !== 'txt') {
                $this->setRedirect(JRoute::_('index.php?option=com_jdownloads', false), JText::_('COM_JDOWNLOADS_RESTORE_MSG_WRONG_FILE_ERROR'), 'error');
                return false;
            }

            $restore_dir = JPath::clean(JFactory::getConfig()->get('tmp_path'));
            $upload_path = $restore_dir.DS.'jdownloads_restore_'.JUserHelper::genRandomPassword(16).'.txt';

            if (!JFile::upload($file['tmp_name'], $upload_path)){
                $app->redirect(JRoute::_('index.php?option=com_jdownloads'),  JText::_('COM_JDOWNLOADS_RESTORE_MSG_STORE_ERROR'), 'error');
            }
            
            if($file['tmp_name']!= ''){

                // Restore only validated jDownloads SQL statements.
                try {
                    $restored_rows = $this->executeRestoreFile($upload_path);
                } catch (RuntimeException $exception) {
                    JFile::delete($upload_path);
                    $this->setRedirect(JRoute::_('index.php?option=com_jdownloads', false), $exception->getMessage(), 'error');
                    return false;
                }
                
                // set off monitoring
                $db->setQuery("UPDATE #__jdownloads_config SET setting_value = '0' WHERE setting_name = 'files.autodetect'");
                $db->execute();
                $jlistConfig['files.autodetect'] = 0;

                // we must restore the original stored upload root dir in config
                $db->setQuery('UPDATE #__jdownloads_config SET setting_value = '.$db->quote($original_upload_dir)." WHERE setting_name = 'files.uploaddir'");
                $db->execute();
                $jlistConfig['files.uploaddir'] = $original_upload_dir;

                // create for every category a data set in the assets table (added in 3.2.22)
                // get at first all items
                $query = $db->getQuery(true);
                $query->select('*');
                $query->from('#__jdownloads_categories');
                $query->order('lft ASC');
                $db->setQuery($query);
                $cats = $db->loadObjectList();
                // we need an array
                $cats = json_decode(json_encode($cats), true);          
                // sum of total categories (but compute not the root)
                $cats_sum = count($cats) - 1;
                
                $sum_updated_cats = 0;
                
                if ($cats_sum){
                    
                    foreach ($cats as $cat){
                        
                        if ($cat['id'] > 1){
                            // add the new rules array
                            $cat['rules'] = array(
                                    'core.create' => array(),
                                    'core.delete' => array(),
                                    'core.edit' => array(),
                                    'core.edit.state' => array(),
                                    'core.edit.own' => array(),
                                    'download' => array(),
                            );
                            // save now the category with the new rules
                            $update_result = $model_category->save( $cat, true );
                            if (!$update_result){
                                // error message
                                $log .= 'Category Results: Can not create new asset rules for category ID '.$cat['id'].'<br />';
                            } else {
                                $sum_updated_cats ++;                        
                            }              

                        }
                    }
                    $log .= "New data sets created in 'assets' db table for categories: ".$sum_updated_cats.'<br />';
                }                
                
                // create for every Download a data set in the assets table (added in 3.2.22)
                // get at first all items
                $query = $db->getQuery(true);
                $query->select('*');
                $query->from('#__jdownloads_files');
                $query->order('file_id ASC');
                $db->setQuery($query);
                $files = $db->loadObjectList();
                // we need an array
                $files = json_decode(json_encode($files), true);          
                // sum of total Downloads
                $files_sum = count($files);
                
                $sum_updated_files = 0;
                
                if ($files_sum){
                    
                    foreach ($files as $file){
                        
                            // add the new rules array
                            $file['rules'] = array(
                                    'core.create' => array(),
                                    'core.delete' => array(),
                                    'core.edit' => array(),
                                    'core.edit.state' => array(),
                                    'core.edit.own' => array(),
                                    'download' => array(),
                            );
                            // save now the download with the new rules
                            $update_result = $model_download->save( $file, true, false, true );
                            if (!$update_result){
                                // error message
                                $log .= 'Downloads Results: Can not create new asset rules for download ID '.$file['file_id'].'<br />';
                            } else {
                                $sum_updated_files ++;                        
                            }              
                    }
                    $log .= "New data sets created in 'assets' db table for downloads: ".$sum_updated_files.'<br />';
                }                
                
                $sum = '<font color="green"><b>'.sprintf(JText::_('COM_JDOWNLOADS_RESTORE_MSG'),(int)$restored_rows).'</b></font>';
                
                if ($log){
                    $output = $db->escape($sum.'<br />'.$output.'<br />'.JText::_('COM_JDOWNLOADS_AFTER_RESTORE_TITLE_3').'<br />'.$log.'<br />'.JText::_('COM_JDOWNLOADS_CHECK_FINISH').'');
                } else {   
                    $output = $db->escape($sum.'<br />'.$output.'<br />'.JText::_('COM_JDOWNLOADS_CHECK_FINISH').'');
                }    
                $db->setQuery('UPDATE #__jdownloads_config SET setting_value = '.$db->quote($output)." WHERE setting_name = 'last.restore.log'");
                $db->execute();
                $jlistConfig['last.restore.log'] = stripslashes($output);
                
                // delete the backup file in temp folder
                JFile::delete($upload_path);
            }
            $this->setRedirect( 'index.php?option=com_jdownloads',  $sum.' '.JText::_('COM_JDOWNLOADS_RESTORE_MSG_2') );
        }    
    }    
	
}
?>
