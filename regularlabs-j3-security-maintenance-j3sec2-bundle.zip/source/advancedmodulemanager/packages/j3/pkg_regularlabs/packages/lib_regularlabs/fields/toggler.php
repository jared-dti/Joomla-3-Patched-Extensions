<?php
/**
 * @package         Regular Labs Library
 * @version         23.9.3039
 * 
 * @author          Peter van Westen <info@regularlabs.com>
 * @link            https://regularlabs.com
 * @copyright       Copyright © 2023 Regular Labs All Rights Reserved
 * @license         GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory as JFactory;
use Joomla\CMS\Form\FormField as JFormField;
use RegularLabs\Library\Document as RL_Document;
use RegularLabs\Library\RegEx as RL_RegEx;

if ( ! is_file(JPATH_LIBRARIES . '/regularlabs/autoload.php'))
{
    return;
}

require_once JPATH_LIBRARIES . '/regularlabs/autoload.php';

/**
 * @deprecated  2018-10-30  Use ShowOn instead
 */

/**
 * To use this, make a start xml param tag with the param and value set
 * And an end xml param tag without the param and value set
 * Everything between those tags will be included in the slide
 *
 * Available extra parameters:
 * param            The name of the reference parameter
 * value            a comma separated list of value on which to show the framework
 */
class JFormFieldRL_Toggler extends JFormField
{
    public $type = 'Toggler';

    protected function getInput()
    {
        if ( ! is_file(JPATH_LIBRARIES . '/regularlabs/autoload.php'))
        {
            return null;
        }

        $field = new RLFieldToggler;

        return $field->getInput($this->element->attributes());
    }

    protected function getLabel()
    {
        return '';
    }
}

class RLFieldToggler
{
    public function getInput($params)
    {
        $this->params = $params;

        $option = JFactory::getApplication()->input->get('option');

        // do not place toggler stuff on JoomFish pages
        if ($option == 'com_joomfish')
        {
            return '';
        }

        $param  = $this->get('param');
        $value  = $this->get('value');
        $nofx   = $this->get('nofx');
        $method = $this->get('method');
        $div    = $this->get('div', 0);

        RL_Document::script('regularlabs/toggler.min.js');

        $param = RL_RegEx::replace('^\s*(.*?)\s*$', '\1', $param);
        $param = RL_RegEx::replace('\s*\|\s*', '|', $param);

        $html = [];

        if ( ! $param)
        {
            return '</div>';
        }

        $param      = RL_RegEx::replace('[^a-z0-9-\.\|\@]', '_', $param);
        $param      = str_replace('@', '_', $param);
        $set_groups = explode('|', $param);
        $set_values = explode('|', $value);
        $ids        = [];

        foreach ($set_groups as $i => $group)
        {
            $count = $i;

            if ($count >= count($set_values))
            {
                $count = 0;
            }

            $value = explode(',', $set_values[$count]);

            foreach ($value as $val)
            {
                $ids[] = $group . '.' . $val;
            }
        }

        if ( ! $div)
        {
            $html[] = '</div></div>';
        }

        $html[] = '<div id="' . rand(1_000_000, 9_999_999) . '___' . implode('___', $ids) . '" class="rl_toggler';

        if ($nofx)
        {
            $html[] = ' rl_toggler_nofx';
        }

        if ($method == 'and')
        {
            $html[] = ' rl_toggler_and';
        }

        $html[] = '">';

        if ( ! $div)
        {
            $html[] = '<div><div>';
        }

        return implode('', $html);
    }

    private function get($val, $default = '')
    {
        if ( ! isset($this->params[$val]) || (string) $this->params[$val] == '')
        {
            return $default;
        }

        return (string) $this->params[$val];
    }
}
