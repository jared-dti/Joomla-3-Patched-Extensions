<?php
/**
 * @package         Regular Labs Library
 * @version         23.9.3039
 * 
 * @author          Peter van Westen <info@regularlabs.com>
 * @link            https://regularlabs.com
 * @copyright       Copyright © 2023 Regular Labs All Rights Reserved
 * @license         GNU General Public License version 2 or later
 */

/* @DEPRECATED */

defined('_JEXEC') or die;

use Joomla\CMS\Factory as JFactory;

if (is_file(JPATH_LIBRARIES . '/regularlabs/autoload.php'))
{
    require_once JPATH_LIBRARIES . '/regularlabs/autoload.php';
}

require_once dirname(__FILE__, 2) . '/assignment.php';

// If controller.php exists, assume this is K2 v3
defined('RL_K2_VERSION') or define('RL_K2_VERSION', file_exists(JPATH_ADMINISTRATOR . '/components/com_k2/controller.php') ? 3 : 2);

class RLAssignmentsK2 extends RLAssignment
{
    public function getItem($fields = [])
    {
        $query = $this->db->getQuery(true)
            ->select($fields)
            ->from('#__k2_items')
            ->where('id = ' . (int) $this->request->id);
        $this->db->setQuery($query);

        return $this->db->loadObject();
    }

    public function passCategories()
    {
        if ($this->request->option != 'com_k2')
        {
            return $this->pass(false);
        }

        $pass = (
            ($this->params->inc_categories
                && (($this->request->view == 'itemlist' && $this->request->task == 'category')
                    || $this->request->view == 'latest'
                )
            )
            || ($this->params->inc_items && $this->request->view == 'item')
        );

        if ( ! $pass)
        {
            return $this->pass(false);
        }

        $cats = $this->makeArray($this->getCategories());
        $pass = $this->passSimple($cats, 'include');

        if ($pass && $this->params->inc_children == 2)
        {
            return $this->pass(false);
        }
        elseif ( ! $pass && $this->params->inc_children)
        {
            foreach ($cats as $cat)
            {
                $cats = array_merge($cats, $this->getCatParentIds($cat));
            }
        }

        return $this->passSimple($cats);
    }

    public function passItems()
    {
        if ( ! $this->request->id || $this->request->option != 'com_k2' || $this->request->view != 'item')
        {
            return $this->pass(false);
        }

        $pass = false;

        // Pass Article Id
        if ( ! $this->passItemByType($pass, 'ContentIds'))
        {
            return $this->pass(false);
        }

        // Pass Content Keywords
        if ( ! $this->passItemByType($pass, 'ContentKeywords'))
        {
            return $this->pass(false);
        }

        // Pass Meta Keywords
        if ( ! $this->passItemByType($pass, 'MetaKeywords'))
        {
            return $this->pass(false);
        }

        // Pass Authors
        if ( ! $this->passItemByType($pass, 'Authors'))
        {
            return $this->pass(false);
        }

        return $this->pass($pass);
    }

    public function passPageTypes()
    {
        return $this->passByPageTypes('com_k2', $this->selection, $this->assignment, false, true);
    }

    public function passTags()
    {
        if ($this->request->option != 'com_k2')
        {
            return $this->pass(false);
        }

        $tag  = trim(JFactory::getApplication()->input->getString('tag', ''));
        $pass = (
            ($this->params->inc_tags && $tag != '')
            || ($this->params->inc_items && $this->request->view == 'item')
        );

        if ( ! $pass)
        {
            return $this->pass(false);
        }

        if ($this->params->inc_tags && $tag != '')
        {
            $tags = [trim(JFactory::getApplication()->input->getString('tag', ''))];

            return $this->passSimple($tags, true);
        }

        $query = $this->db->getQuery(true)
            ->select('t.name')
            ->from('#__k2_tags_xref AS x')
            ->join('LEFT', '#__k2_tags AS t ON t.id = x.tagID')
            ->where('x.itemID = ' . (int) $this->request->id)
            ->where('t.published = 1');
        $this->db->setQuery($query);
        $tags = $this->db->loadColumn();

        return $this->passSimple($tags, true);
    }

    private function getCatParentIds($id = 0)
    {
        $parent_field = RL_K2_VERSION == 3 ? 'parent_id' : 'parent';

        return $this->getParentIds($id, 'k2_categories', $parent_field);
    }

    private function getCategories()
    {
        switch ($this->request->view)
        {
            case 'item' :
                return $this->getCategoryIDFromItem();
                break;

            case 'itemlist' :
                return $this->getCategoryID();
                break;

            default:
                return '';
        }
    }

    private function getCategoryID()
    {
        return $this->request->id ?: JFactory::getApplication()->getUserStateFromRequest('com_k2itemsfilter_category', 'catid', 0, 'int');
    }

    private function getCategoryIDFromItem()
    {
        if ($this->article && isset($this->article->catid))
        {
            return $this->article->catid;
        }

        $query = $this->db->getQuery(true)
            ->select('i.catid')
            ->from('#__k2_items AS i')
            ->where('i.id = ' . (int) $this->request->id);
        $this->db->setQuery($query);

        return $this->db->loadResult();
    }
}
