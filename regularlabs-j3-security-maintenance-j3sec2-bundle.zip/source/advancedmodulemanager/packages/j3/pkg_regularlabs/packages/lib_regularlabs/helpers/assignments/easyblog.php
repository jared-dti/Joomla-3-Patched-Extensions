<?php
/**
 * @package         Regular Labs Library
 * @version         23.9.3039
 * 
 * @author          Peter van Westen <info@regularlabs.com>
 * @link            https://regularlabs.com
 * @copyright       Copyright © 2023 Regular Labs All Rights Reserved
 * @license         GNU General Public License version 2 or later
 */

/* @DEPRECATED */

defined('_JEXEC') or die;

if (is_file(JPATH_LIBRARIES . '/regularlabs/autoload.php'))
{
    require_once JPATH_LIBRARIES . '/regularlabs/autoload.php';
}

require_once dirname(__FILE__, 2) . '/assignment.php';

class RLAssignmentsEasyBlog extends RLAssignment
{
    public function getItem($fields = [])
    {
        $query = $this->db->getQuery(true)
            ->select($fields)
            ->from('#__easyblog_post')
            ->where('id = ' . (int) $this->request->id);
        $this->db->setQuery($query);

        return $this->db->loadObject();
    }

    public function passCategories()
    {
        if ($this->request->option != 'com_easyblog')
        {
            return $this->pass(false);
        }

        $pass = (
            ($this->params->inc_categories && $this->request->view == 'categories')
            || ($this->params->inc_items && $this->request->view == 'entry')
        );

        if ( ! $pass)
        {
            return $this->pass(false);
        }

        $cats = $this->makeArray($this->getCategories());

        $pass = $this->passSimple($cats, 'include');

        if ($pass && $this->params->inc_children == 2)
        {
            return $this->pass(false);
        }
        elseif ( ! $pass && $this->params->inc_children)
        {
            foreach ($cats as $cat)
            {
                $cats = array_merge($cats, $this->getCatParentIds($cat));
            }
        }

        return $this->passSimple($cats);
    }

    public function passContentKeywords($fields = ['title', 'intro', 'content'], $text = '')
    {
        parent::passContentKeywords($fields);
    }

    public function passItems()
    {
        if ( ! $this->request->id || $this->request->option != 'com_easyblog' || $this->request->view != 'entry')
        {
            return $this->pass(false);
        }

        $pass = false;

        // Pass Article Id
        if ( ! $this->passItemByType($pass, 'ContentIds'))
        {
            return $this->pass(false);
        }

        // Pass Content Keywords
        if ( ! $this->passItemByType($pass, 'ContentKeywords'))
        {
            return $this->pass(false);
        }

        // Pass Authors
        if ( ! $this->passItemByType($pass, 'Authors'))
        {
            return $this->pass(false);
        }

        return $this->pass($pass);
    }

    public function passPageTypes()
    {
        return $this->passByPageTypes('com_easyblog', $this->selection, $this->assignment);
    }

    public function passTags()
    {
        if ($this->request->option != 'com_easyblog')
        {
            return $this->pass(false);
        }

        $pass = (
            ($this->params->inc_tags && $this->request->layout == 'tag')
            || ($this->params->inc_items && $this->request->view == 'entry')
        );

        if ( ! $pass)
        {
            return $this->pass(false);
        }

        if ($this->params->inc_tags && $this->request->layout == 'tag')
        {
            $query = $this->db->getQuery(true)
                ->select('t.alias')
                ->from('#__easyblog_tag AS t')
                ->where('t.id = ' . (int) $this->request->id)
                ->where('t.published = 1');
            $this->db->setQuery($query);
            $tags = $this->db->loadColumn();

            return $this->passSimple($tags, true);
        }

        $query = $this->db->getQuery(true)
            ->select('t.alias')
            ->from('#__easyblog_post_tag AS x')
            ->join('LEFT', '#__easyblog_tag AS t ON t.id = x.tag_id')
            ->where('x.post_id = ' . (int) $this->request->id)
            ->where('t.published = 1');
        $this->db->setQuery($query);
        $tags = $this->db->loadColumn();

        return $this->passSimple($tags, true);
    }

    private function getCatParentIds($id = 0)
    {
        return $this->getParentIds($id, 'easyblog_category', 'parent_id');
    }

    private function getCategories()
    {
        switch ($this->request->view)
        {
            case 'entry' :
                return $this->getCategoryIDFromItem();
                break;

            case 'categories' :
                return $this->request->id;
                break;

            default:
                return '';
        }
    }

    private function getCategoryIDFromItem()
    {
        $query = $this->db->getQuery(true)
            ->select('i.category_id')
            ->from('#__easyblog_post AS i')
            ->where('i.id = ' . (int) $this->request->id);
        $this->db->setQuery($query);

        return $this->db->loadResult();
    }
}
