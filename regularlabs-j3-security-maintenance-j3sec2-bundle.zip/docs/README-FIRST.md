# Regular Labs Joomla 3 security-maintenance build `j3sec2`

These five ZIP files are installable packages built solely for Joomla 3 / PHP 7.4. Each installer contains only its Joomla 3 payload and refuses installation on every other Joomla major version during preflight.

## Changes since `j3sec1`

- Removed the unused non-Joomla-3 payload from all five installers and made the outer package scripts Joomla-3-only.
- Removed ReReplacer's unreachable PHP-replacement runner and its now-unused `Code.php` implementation.
- Removed Sourcerer's unreachable legacy final-output execution body while retaining fail-closed source cleanup.
- Added the required pre-install Sourcerer module inventory and clarified its code-execution trust boundary.
- Documented Sourcerer's silent article denial behavior and the exact creator/modifier authorization rule.

## Installers

- `advancedmodulemanager-v9.9.0-pro-j3sec2.zip`
- `cachecleaner-v8.5.0-pro-j3sec2.zip`
- `modulesanywhere-v7.18.0-pro-j3sec2.zip`
- `rereplacer-v13.2.0-pro-j3sec2.zip`
- `sourcerer-v9.8.0-pro-j3sec2.zip`

## Required Sourcerer inventory before installation

Run this query on each site's Joomla database before installing and record every returned module ID, title, and position:

```sql
SELECT id, title, position FROM `#__modules`
WHERE module = 'mod_custom' AND content LIKE '%{source%';
```

Replace `#__` with that site's configured Joomla table prefix if the database tool does not expand Joomla placeholders. The **Trusted custom module IDs** setting defaults to blank, so failing to record these IDs first can disable existing Sourcerer-powered Custom HTML modules without leaving an inventory of what must be re-enabled.

Install each ZIP over the existing package with Joomla 3's Extensions > Manage > Install uploader. Do not uninstall first; doing so can discard configuration. Each package contains the same patched Joomla 3 Regular Labs Library, so their install order is not security-sensitive. For functional testing, use this order:

1. Advanced Module Manager
2. Modules Anywhere
3. Cache Cleaner
4. ReReplacer
5. Sourcerer

Use one representative site or a restorable copy first. Preserve a file/database backup and the original five installers so the test can be rolled back.

## Required acceptance tests

### Advanced Module Manager

1. Open two existing modules and confirm their page/menu/assignment settings still load and save.
2. Confirm a user without edit permission cannot duplicate, recolor, reorder, or edit another module by changing an ID in the request.
3. Confirm the module list and assignment selectors still populate in the administrator.

### Modules Anywhere — highest functional priority

1. Put an existing published form-module tag in the same third-party-extension content location used in production, for example `{module 123}`, and submit the form end to end.
2. Confirm an unpublished module does not render.
3. Confirm a module outside the visitor's Joomla view level does not render.
4. Confirm `ignore_access=1` and `ignore_state=1` in a content tag do not bypass those controls.
5. Confirm tag-provided `content`, `title`, and arbitrary parameter overrides are ignored.
6. Confirm a module that embeds itself stops without exhausting PHP memory.

The retained tag controls are module ID/title selection, a sanitized chrome/style name, `showtitle`, `fixhtml`, `ignore_assignments`, and `ignore_caching`. Access and publication bypasses are always disabled.

### Cache Cleaner

1. While logged into the administrator as a user with `core.manage` for `com_cache`, click the Cache Cleaner toolbar/status button. Joomla cache clearing should complete.
2. If Cloudflare is configured, confirm a purge completes using credentials already saved in plugin parameters.
3. In a logged-out browser, request `/index.php?cleancache=anything`. It must not purge.
4. Confirm an administrator user without cache-management permission cannot purge.

Retained: Joomla cache purge, expired-cache purge, asset-cache refresh, and Cloudflare purge. Removed/disabled: public secret-URL purge, interval-on-visitor purge, request-selected third-party providers, arbitrary query URLs, custom folder/table/file purges, SiteGround shell/loopback logic, KeyCDN/CDN77 URL credential controls, LiteSpeed, OPcache, update cache, check-in, and configurable log paths.

### ReReplacer

1. Test several existing ordinary text replacements on article and final-page output.
2. Test any regular-expression replacement you intend to retain.
3. Confirm rules configured for PHP replacement execute as ordinary non-PHP content or remain inactive; PHP execution is forced off.
4. Confirm XML include rules are inactive; XML mode is forced off.
5. Confirm import/export/copy actions are rejected. These legacy transfer paths were not required for runtime replacement and are disabled.

Smart Search indexing does not evaluate ReReplacer rules in an administrator/CLI identity.

### Sourcerer

1. Test stored `{source}` code in an article whose creator has Joomla `core.admin` authorization and whose last modifier also has `core.admin` when `modified_by` is nonzero. When `modified_by` is zero or absent, the creator is used for both checks. If either required account lacks authorization, the source block is removed silently: the page shows no warning or error and the affected content simply disappears. Support staff investigating a newly broken page should check the article's last modifier first.
2. For each Custom HTML module that must execute Sourcerer, open the Sourcerer system-plugin settings and enter its numeric Joomla module ID in **Trusted custom module IDs**. The setting is comma-separated and defaults to blank (all custom modules denied). Allowlisting a module grants arbitrary PHP execution in the Joomla site process to anyone who can edit that module; add only recorded module IDs whose edit permissions are already restricted to fully trusted administrators.
3. Test the allowlisted Custom HTML module. Confirm a non-allowlisted module does not execute source.
4. Submit `{source}` or encoded equivalents in a query string, form name/value, JSON body, cookie, header, or upload. Request-origin source must not execute.

Dynamic include/require attributes, execution from arbitrary component/final-output provenance, and source generated only during late rendering are disabled.

## Important incident boundary

These packages close the reviewed extension paths; they do not prove that a previously compromised site is clean. Before returning a compromised site to normal service, compare its PHP files with known-good distributions, inspect recently modified files and writable directories, remove unauthorized Joomla users/scheduled tasks, inspect database content for injected code, and rotate Joomla/database/hosting/API credentials. A surviving backdoor can reinfect a correctly patched extension.

See `SECURITY-CHANGES.md`, `VALIDATION-REPORT.md`, and `SHA256SUMS.txt` for the exact controls and build evidence.
