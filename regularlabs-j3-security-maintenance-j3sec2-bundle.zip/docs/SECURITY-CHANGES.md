# Security changes and research mapping — `j3sec2`

Build date: 8 September 2026. Target runtime: Joomla 3 and PHP 7.4.

## Changes since `j3sec1`

- Removed every non-Joomla-3 package payload and manifest entry from all five installers.
- Added an explicit Joomla-3-only preflight guard to all five outer package scripts and removed their unused higher-version branches.
- Physically removed ReReplacer's unreachable PHP execution chain and the now-unreferenced `Code.php` implementation.
- Physically removed Sourcerer's unreachable late-output execution body; its fail-closed cleanup remains unchanged.
- Corrected the Sourcerer deployment documentation without weakening any `j3sec1` control.

## Shared Regular Labs Library (identical in all five installers)

- Administrator AJAX requests now require an authenticated administrator session and a valid Joomla request token.
- AJAX payloads are generated server-side with component/view/item context and authenticated with HMAC-SHA256 using the Joomla site secret.
- The receiving endpoint rejects unsigned/modified form configuration, unknown component names, users without `core.manage` (or `core.admin`), non-form-field handlers, malformed Base64, and inflated payloads above 1 MiB.
- QuickPage editor popups are administrator/authentication gated; file popups require a request token, and the editor-button helper supplies it.
- This directly addresses the supplied code's form-field dispatch weakness corresponding to CVE-2026-63265.

The supplied Joomla 3 packages do not contain `guzzlehttp/psr7`, so CVE-2026-55766's vulnerable dependency is not present in these builds.

## Cache Cleaner 8.5.0 PRO

- CVE-2026-64871: all manual purge requests are administrator-only, authenticated, request-token checked, and require `core.admin` or `core.manage` on `com_cache`.
- CVE-2026-64872: configurable purge/log filesystem paths and folder/table/file purge operations are removed; logs use the fixed Cache Cleaner plugin directory.
- CVE-2026-64873: arbitrary custom query URLs and request-selected third-party purge dispatch are removed.
- CVE-2026-64874: provider credentials are never accepted from purge request URLs; KeyCDN/CDN77 AJAX credential buttons are removed. Cloudflare reads saved plugin parameters only.
- SiteGround purge code is disabled, removing the request-host-to-shell/loopback path found in the old implementation.
- Cloudflare requests require HTTPS, verify the TLS peer and hostname, refuse redirects, and use finite connect/total timeouts.
- Anonymous interval purging and the legacy public secret-URL purge are disabled.

## ReReplacer 13.2.0 PRO

- CVE-2026-65754: XML include mode is forced off in validation, save, database loading, and execution. Existing XML path data cannot be used at runtime.
- PHP replacement mode is forced off in validation, save, database loading, and execution. Ordinary text/regular-expression replacement remains.
- Legacy import/export/copy controller actions are denied; save-order and state actions require Joomla tokens and matching permissions.
- Export ID values are integer-filtered before query construction even though the controller route is disabled.
- Smart Search indexing skips ReReplacer evaluation to prevent administrator/CLI-context output from entering the public index.
- Shared privileged AJAX protection covers CVE-2026-63265.

## Modules Anywhere 7.18.0 PRO

- Module queries always enforce Joomla view levels, published state, and extension enabled state.
- Content tags cannot reinstate `ignore_access` or `ignore_state` through legacy global settings, shortcode flags, or property overrides.
- Shortcodes can no longer override module content, title, or arbitrary module/Advanced Module Manager parameters. Only the documented reduced allowlist in `README-FIRST.md` remains.
- Style/chrome input is restricted to alphanumeric, underscore, and hyphen characters; Boolean tag controls are normalized.
- Direct and indirect recursive module rendering is detected and stopped.
- The editor popup and shared AJAX lookup require authenticated administrator context and valid request tokens.

## Advanced Module Manager 9.9.0 PRO

- Module duplicate, color, ordering, and position actions require Joomla request tokens and matching create/edit permissions for each module ID.
- Request IDs are read as integers.
- Frontend component access no longer treats a missing module ID as authorization; it requires global frontend module-edit permission or permission for the exact nonzero module ID.
- Shared AJAX form configuration is signed, token checked, and permission checked.
- Joomla 3's assignment implementation is retained.

## Sourcerer 9.8.0 PRO

- CVE-2026-74253: request-origin `{source}` syntax is detected in request names and values, query/form arrays, JSON, cookies, selected server/header values, raw bodies, and uploads, including repeated URL/HTML decoding. Detection is sticky for 60 seconds in the site session and fails closed for streams above 2 MiB or stream-read failures.
- Source execution is limited to exact stored Joomla article content and explicitly allowlisted, published Custom HTML module content.
- Article execution requires the database-record creator and, when `modified_by` is nonzero, the last modifier to hold Joomla `core.admin`; a zero or absent modifier falls back to the creator. Legacy group settings cannot broaden this.
- Custom HTML execution defaults off and requires numeric IDs in **Trusted custom module IDs**. An allowlisted module is an arbitrary-PHP trust boundary and must remain editable only by fully trusted administrators.
- Component-buffer and late final-output execution are disabled; leftover source blocks are removed rather than evaluated.
- Dynamic file include/require and media-loading source-tag attributes are disabled.
- Editor popup access uses the patched QuickPage authentication/token controls.

## Public evidence reviewed

- NVD CVE-2026-63265: https://nvd.nist.gov/vuln/detail/CVE-2026-63265
- NVD CVE-2026-64871: https://nvd.nist.gov/vuln/detail/CVE-2026-64871
- NVD CVE-2026-64872: https://nvd.nist.gov/vuln/detail/CVE-2026-64872
- NVD CVE-2026-64873: https://nvd.nist.gov/vuln/detail/CVE-2026-64873
- NVD CVE-2026-64874: https://nvd.nist.gov/vuln/detail/CVE-2026-64874
- NVD CVE-2026-65754: https://nvd.nist.gov/vuln/detail/CVE-2026-65754
- NVD CVE-2026-74253: https://nvd.nist.gov/vuln/detail/CVE-2026-74253
- Official Modules Anywhere release history: https://regularlabs.com/modulesanywhere/download
- Official Cache Cleaner release history: https://regularlabs.com/cachecleaner/download
- Official ReReplacer release history: https://regularlabs.com/rereplacer/download
- Official Sourcerer release history: https://regularlabs.com/sourcerer/download
- Official Advanced Module Manager release history: https://regularlabs.com/advancedmodulemanager/download

The reviewed public sources document the vulnerabilities and fixes. They did not provide credible, verifiable evidence tying a specific public in-the-wild campaign to these exact supplied package versions. That does not contradict the reported compromises; it means attribution needs each site's logs and forensic artifacts.
