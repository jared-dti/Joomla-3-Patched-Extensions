# Validation report — `j3sec2`

Build date: 8 September 2026. Target runtime: Joomla 3.10.12 and PHP 7.4.33.

## Changes since `j3sec1`

- Removed every non-Joomla-3 payload directory and outer-manifest entry.
- Added explicit Joomla-3-only preflight rejection to all five outer installers.
- Removed the verified-unreachable ReReplacer PHP runner and Sourcerer late-output execution body.
- Corrected the Sourcerer deployment and trust-boundary documentation.

## Automated results

- Exact compatibility runtime: official Windows PHP 7.4.33 CLI with `-n` (no `php.ini`) for syntax and security tests.
- PHP 7.4 syntax: 1,415 remaining package PHP files checked; 0 failures. This includes each outer `script.install.php` and 1,410 files in the Joomla 3 payloads.
  - Advanced Module Manager: 317
  - Cache Cleaner: 277
  - Modules Anywhere: 266
  - ReReplacer: 283
  - Sourcerer: 272
- PHP 8-only function scan: 0 calls to `str_contains`, `str_starts_with`, `str_ends_with`, `array_is_list`, `get_debug_type`, or `enum_exists`.
- PHP 8-only syntax: 0 occurrences accepted into the build; every PHP file parsed successfully under PHP 7.4.33, which rejects PHP 8-only syntax.
- XML parsing: 49 remaining manifest XML files checked; 0 failures.
- Modified Cache Cleaner JavaScript: 2 files checked with Node `--check`; 0 failures.
- Static security-policy assertions: 78 passed.
- Sourcerer adversarial request-origin tests: 11 passed.
  - Plain/case-varied source syntax
  - Percent and double-percent encoding
  - HTML entities
  - Nested JSON
  - Array-key injection
  - Clean-control cases
  - Source marker split across stream chunks
  - Oversized stream fail-closed behavior
- Joomla-version boundary: 0 `packages/j4` directories, 0 `<files_j4>` blocks, and all five package scripts reject `(int) JVERSION !== 3` before payload or version-map access.
- Shared patched Regular Labs Library: every package contains 393 files and produces the identical tree SHA-256 `6e718893d576d5c3baf47815900d17f8f8e50e0ad290067321e568b1c0399cfa`.

The tree digest is reproducible from the extracted build root with the included PHP 7.4-compatible helper:

```powershell
php.exe -n tests/library_tree_hash.php advancedmodulemanager/packages/j3/pkg_regularlabs
```

The helper sorts normalized relative paths bytewise, then hashes each record as `relative-path`, a NUL byte, the file's lowercase SHA-256, and a newline. Running the same command with each of the other four package directories returns the same count and digest.

- ZIP round-trip: every source file was present in its installer and matched byte-for-byte by SHA-256.
  - Advanced Module Manager: 730 files, 0 failures
  - Cache Cleaner: 597 files, 0 failures
  - Modules Anywhere: 577 files, 0 failures
  - ReReplacer: 650 files, 0 failures
  - Sourcerer: 566 files, 0 failures
- All outer package versions carry the `-j3sec2` marker.

## Validation boundary

No running Joomla 3 site, database, web server, Cloudflare account, form extension, or production configuration was available in this workspace. The packages have been code-audited, compatibility-linted, policy-tested, and archive-verified, but they have not yet passed Joomla installation/runtime integration. The functional acceptance sequence in `README-FIRST.md` is the deployment gate before fleet rollout.

These tests also do not certify that an already compromised site is free of persistence. That requires per-site incident inspection.
